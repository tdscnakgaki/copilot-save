from collections import Counter
from pathlib import Path
import csv


SOURCE = Path("/root/.copilot/uploads/2026-11-19-2ea86484/261119.cdb")
OUTPUT = Path(__file__).parent / "261119_simple_material.cdb"
DUPLICATES = Path(__file__).parent / "261119_removed_duplicate_elements.csv"


def read_mesh(lines):
    node_lines = []
    elements = []
    i = 0
    while i < len(lines):
        if lines[i].startswith("NBLOCK,"):
            assert lines[i + 1].strip().lower() == "(3i8,6e16.9)"
            i += 2
            while not lines[i].lstrip().startswith("N,"):
                node_lines.append(lines[i])
                i += 1
        elif lines[i].startswith("EBLOCK,"):
            assert lines[i + 1].strip().lower() == "(19i8)"
            i += 2
            while lines[i].strip() != "-1":
                row = lines[i]
                values = [
                    int(row[j:j + 8])
                    for j in range(0, len(row), 8)
                    if row[j:j + 8].strip()
                ]
                assert len(values) == 19 and values[8] == 8
                assert len(set(values[11:])) == 4
                elements.append(values)
                i += 1
        i += 1
    return node_lines, elements


nodes, elements = read_mesh(SOURCE.read_text().splitlines())
node_ids = {int(row[:8]) for row in nodes}
assert len(node_ids) == len(nodes)
assert len({v[10] for v in elements}) == len(elements)
kept = []
seen = {}
removed = []
for values in elements:
    key = tuple(sorted(set(values[11:])))
    assert set(key) <= node_ids
    if key in seen:
        removed.append((values[10], seen[key], *key))
        continue
    seen[key] = values[10]
    values[0] = 1
    values[1] = 1
    kept.append(values)

assert len(nodes) == 24886
assert len(elements) == 102121
assert len(removed) == 191
assert len(kept) == 101930

with OUTPUT.open("w", newline="\n") as out:
    out.write(
        "! Simplified single-material mesh derived from 261119.cdb\n"
        "! Read into a NEW/EMPTY ANSYS database. Units assumed: mm, N, MPa.\n"
        "! Material matches Jade-A material 1: EX=181300 MPa, PRXY=0.3.\n"
        "! Original coordinates and retained element connectivity are preserved.\n"
        "! 191 exact duplicate tetrahedra removed; first occurrence retained.\n"
        "! Stale source quality components omitted (their element IDs are absent).\n"
        "! No supports, loads, density, couplings, or solve commands included.\n"
        "! No ANSYS import/solution or mesh-convergence verification performed.\n"
        "/PREP7\n"
        "ET,1,185\n"
        "MP,EX,1,181300\n"
        "MP,PRXY,1,0.3\n"
        "NBLOCK,6,SOLID\n"
        "(3i8,6e16.9)\n"
    )
    out.write("\n".join(nodes) + "\n")
    out.write("N,R5.3,LOC,     -1,\n")
    out.write("EBLOCK,19,SOLID,\n(19i8)\n")
    for values in kept:
        out.write("".join(f"{value:8d}" for value in values) + "\n")
    out.write("      -1\nESEL,ALL\nCM,SUSPENSION,ELEM\nALLSEL,ALL\nFINISH\n")

with DUPLICATES.open("w", newline="") as out:
    writer = csv.writer(out)
    writer.writerow(
        ["removed_element", "retained_element", "node_1", "node_2", "node_3", "node_4"]
    )
    writer.writerows(removed)

check_nodes, check_elements = read_mesh(OUTPUT.read_text().splitlines())
assert check_nodes == nodes
assert check_elements == kept
assert Counter((v[0], v[1]) for v in check_elements) == {(1, 1): 101930}
assert len({tuple(sorted(set(v[11:]))) for v in check_elements}) == len(kept)
print(f"Created: {OUTPUT}")
print(f"Duplicate log: {DUPLICATES}")
print(f"Nodes: {len(nodes)}; elements: {len(kept)}; removed duplicates: {len(removed)}")
