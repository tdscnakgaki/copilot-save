from collections import Counter
from pathlib import Path
from xml.sax.saxutils import escape
import math


SOURCE = Path("/root/.copilot/uploads/2026-11-19-2ea86484/TDSC_Jade-A_20261111.cdb")
OUTPUT = Path("/mnt/data/TDSC_Jade-A_20261111_isometric.svg")
REINFORCED_OUTPUT = Path("/mnt/data/TDSC_Jade-A_tip_thickness_selection.svg")
WIDTH, HEIGHT = 1600, 1200
REINFORCED_X_MIN = 11.4
REINFORCED_X_MAX = 12.87531


def parse_mesh(lines):
    nodes = {}
    elements = []
    i = 0
    while i < len(lines):
        if lines[i].startswith("NBLOCK,"):
            assert lines[i + 1].strip().lower() == "(3i9,6e21.13e3)"
            count = int(lines[i].split(",")[4])
            i += 2
            for row in lines[i:i + count]:
                node_id = int(row[:9])
                nodes[node_id] = tuple(
                    float(row[27 + 21 * axis:27 + 21 * (axis + 1)].strip() or "0")
                    for axis in range(3)
                )
            assert len(nodes) == count
            i += count
        elif lines[i].startswith("EBLOCK,"):
            assert lines[i + 1].strip().lower() == "(19i10)"
            count = int(lines[i].split(",")[4])
            i += 2
            for row in lines[i:i + count]:
                values = [
                    int(row[j:j + 10])
                    for j in range(0, len(row), 10)
                    if row[j:j + 10].strip()
                ]
                assert len(values) == 11 + values[8]
                elements.append((values[1], values[0], values[2], values[11:]))
            i += count
        i += 1
    assert len(nodes) == 149808
    assert len(elements) == 103856
    return nodes, elements


nodes, elements = parse_mesh(SOURCE.read_text(errors="replace").splitlines())
face_counts = Counter()
faces = {}
shell_faces = []
reinforced_shell_faces = []
links = []
solid_count = 0
shell_count = 0


def is_reinforced_shell(material, real, conn):
    centroid_x = sum(nodes[node][0] for node in conn) / len(conn)
    return (
        material == 1
        and real == 2
        and REINFORCED_X_MIN <= centroid_x <= REINFORCED_X_MAX
    )


def add_solid_face(face):
    key = tuple(sorted(face))
    face_counts[key] += 1
    faces[key] = face


for element_type, material, real, conn in elements:
    unique = tuple(dict.fromkeys(conn))
    if element_type == 1:
        shell_count += 1
        shell_faces.append(unique)
        if is_reinforced_shell(material, real, conn):
            reinforced_shell_faces.append(unique)
    elif element_type in (2, 4):
        solid_count += 1
        if len(unique) == 4:
            a, b, c, d = unique
            local_faces = ((a, b, c), (a, d, b), (a, c, d), (b, d, c))
        elif len(unique) == 6:
            a, b, c, _, d, e, f, _ = conn
            local_faces = (
                (a, b, c), (d, e, f), (a, b, e, d),
                (b, c, f, e), (c, a, d, f),
            )
        elif len(unique) == 8:
            a, b, c, d, e, f, g, h = conn
            local_faces = (
                (a, b, c, d), (e, h, g, f), (a, e, f, b),
                (b, f, g, c), (c, g, h, d), (d, h, e, a),
            )
        else:
            raise ValueError(f"Unexpected solid connectivity with {len(unique)} nodes")
        for face in local_faces:
            add_solid_face(face)
    elif len(unique) == 2:
        links.append(unique)

boundary_faces = [faces[key] for key, count in face_counts.items() if count == 1]

right = (1 / math.sqrt(2), 1 / math.sqrt(2), 0.0)
up = (-1 / math.sqrt(6), 1 / math.sqrt(6), 2 / math.sqrt(6))
depth_axis = (1 / math.sqrt(3), -1 / math.sqrt(3), 1 / math.sqrt(3))


def project(point):
    return (
        sum(point[i] * right[i] for i in range(3)),
        sum(point[i] * up[i] for i in range(3)),
        sum(point[i] * depth_axis[i] for i in range(3)),
    )


all_ids = set()
for face in boundary_faces + shell_faces:
    all_ids.update(face)
for link in links:
    all_ids.update(link)
projected = {node: project(nodes[node]) for node in all_ids}
min_x = min(p[0] for p in projected.values())
max_x = max(p[0] for p in projected.values())
min_y = min(p[1] for p in projected.values())
max_y = max(p[1] for p in projected.values())
scale = min(1320 / (max_x - min_x), 980 / (max_y - min_y))
offset_x = (WIDTH - (max_x - min_x) * scale) / 2 - min_x * scale
offset_y = 625 + (max_y - min_y) * scale / 2 + min_y * scale


def svg_point(node):
    x, y, depth = projected[node]
    return offset_x + scale * x, offset_y - scale * y, depth


def polygon(face, fill, opacity="1"):
    points = [svg_point(node) for node in face]
    coords = " ".join(f"{x:.2f},{y:.2f}" for x, y, _ in points)
    avg_depth = sum(point[2] for point in points) / len(points)
    return avg_depth, (
        f'<polygon points="{coords}" fill="{fill}" fill-opacity="{opacity}"/>'
    )


polygons = []
for face in boundary_faces:
    points = [nodes[node] for node in face]
    u = tuple(points[1][i] - points[0][i] for i in range(3))
    v = tuple(points[2][i] - points[0][i] for i in range(3))
    normal = (
        u[1] * v[2] - u[2] * v[1],
        u[2] * v[0] - u[0] * v[2],
        u[0] * v[1] - u[1] * v[0],
    )
    norm = math.sqrt(sum(x * x for x in normal)) or 1
    light = (0.25, -0.45, 0.86)
    brightness = 0.74 + 0.24 * abs(sum(normal[i] * light[i] for i in range(3)) / norm)
    color = f"rgb({int(104 * brightness)},{int(151 * brightness)},{int(184 * brightness)})"
    polygons.append(polygon(face, color))

reinforced_face_keys = {tuple(sorted(face)) for face in reinforced_shell_faces}
for face in shell_faces:
    if tuple(sorted(face)) in reinforced_face_keys:
        polygons.append(polygon(face, "#ffd52a", "0.96"))
    else:
        polygons.append(polygon(face, "#88b8d0", "0.68"))

polygons.sort(key=lambda item: item[0])

svg = [
    f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{HEIGHT}" viewBox="0 0 {WIDTH} {HEIGHT}">',
    '<rect width="100%" height="100%" fill="#ffffff"/>',
    '<text x="800" y="52" text-anchor="middle" font-family="Arial,sans-serif" font-size="29" font-weight="600" fill="#243746">TDSC_Jade-A_20261111 — Isometric mesh view</text>',
    '<text x="800" y="82" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" fill="#526573">ANSYS CDB mesh | schematic rendering, not a structural-analysis result</text>',
]
svg.extend(item[1] for item in polygons)

link_lines = []
for link in links:
    p1 = svg_point(link[0])
    p2 = svg_point(link[1])
    link_lines.append(
        (0.5 * (p1[2] + p2[2]),
         f'<line x1="{p1[0]:.2f}" y1="{offset_y - scale * projected[link[0]][1]:.2f}" '
         f'x2="{p2[0]:.2f}" y2="{offset_y - scale * projected[link[1]][1]:.2f}" '
         'stroke="#455a64" stroke-width="1.2"/>')
    )
svg.extend(line for _, line in sorted(link_lines))
svg.append(
    '<text x="800" y="1147" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" fill="#526573">'
    f'{solid_count:,} solid elements · {shell_count:,} shell elements · {len(boundary_faces):,} exterior solid faces · axes shown in isometric projection</text>'
)

origin = (92, 1070)
axis_vectors = {"X": (36, 21), "Y": (36, -21), "Z": (0, -42)}
for label, (dx, dy) in axis_vectors.items():
    x, y = origin
    svg.append(
        f'<line x1="{x}" y1="{y}" x2="{x + dx}" y2="{y + dy}" stroke="#344955" stroke-width="2.4" marker-end="url(#arrow)"/>'
    )
    svg.append(
        f'<text x="{x + dx * 1.18:.1f}" y="{y + dy * 1.18:.1f}" font-family="Arial,sans-serif" font-size="16" fill="#344955">{label}</text>'
    )
svg.insert(2, '<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="none" stroke="#344955" stroke-width="1.3"/></marker></defs>')
svg.append("</svg>")
svg_text = "\n".join(svg)
OUTPUT.write_text(svg_text)

highlighted_svg = svg_text.replace(
    "TDSC_Jade-A_20261111 — Isometric mesh view",
    "TDSC_Jade-A — Tip shell-thickness selection",
).replace(
    "ANSYS CDB mesh | schematic rendering, not a structural-analysis result",
    "Yellow: approximate region assigned +0.03 mm shell thickness | not solved",
)
REINFORCED_OUTPUT.write_text(highlighted_svg)
print(f"Created {OUTPUT}")
print(f"Created {REINFORCED_OUTPUT}")
print(f"Nodes: {len(nodes):,}; solid elements: {solid_count:,}; shell elements: {shell_count:,}; exterior solid faces: {len(boundary_faces):,}; link elements: {len(links):,}")
print(f"Highlighted shell elements: {len(reinforced_shell_faces):,}")
