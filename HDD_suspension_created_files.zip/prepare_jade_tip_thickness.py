from pathlib import Path
import re


SOURCE = Path(
    "/root/.copilot/uploads/2026-11-19-2ea86484/TDSC_Jade-A_20261111.cdb"
)
OUTPUT = Path("/mnt/data/TDSC_Jade-A_tip_thickness_plus_003.cdb")
MIN_X = 11.4
MAX_X = 12.87531
ORIGINAL_THICKNESS = 0.0305
NEW_THICKNESS = ORIGINAL_THICKNESS + 0.03


lines = SOURCE.read_text(errors="replace").splitlines()
nodes = {}
target_elements = []
element_lines = []
index = 0

while index < len(lines):
    line = lines[index]
    if line.startswith("NBLOCK,"):
        assert lines[index + 1].strip().lower() == "(3i9,6e21.13e3)"
        count = int(line.split(",")[4])
        index += 2
        for row in lines[index:index + count]:
            node_id = int(row[:9])
            nodes[node_id] = tuple(
                float(row[27 + 21 * axis:27 + 21 * (axis + 1)].strip() or "0")
                for axis in range(3)
            )
        assert len(nodes) == count
        index += count
    elif line.startswith("EBLOCK,"):
        assert lines[index + 1].strip().lower() == "(19i10)"
        count = int(line.split(",")[4])
        index += 2
        for row in lines[index:index + count]:
            values = [
                int(row[start:start + 10])
                for start in range(0, len(row), 10)
                if row[start:start + 10].strip()
            ]
            assert len(values) == 11 + values[8]
            element_lines.append((row, values))
            if values[1] != 1 or values[0] != 1 or values[2] != 2:
                continue
            element_nodes = values[11:]
            cx = sum(nodes[node][0] for node in element_nodes) / len(element_nodes)
            if MIN_X <= cx <= MAX_X:
                target_elements.append(values[10])
        index += count
    index += 1

assert len(nodes) == 149808
assert len(element_lines) == 103856
assert target_elements

marker = next(i for i, line in enumerate(lines) if line.strip() == "/GO")
commands = [
    "! Approximate tip-region reinforcement: X centroid 11.4 to 12.87531 mm.",
    "! Selected SHELL181, MAT 1, original real set 2 (thickness 0.0305 mm).",
    "! New thickness 0.0605 mm; shell thickness increase is centered about its",
    "! original reference surface, not a one-sided geometric offset.",
    "! Region was inferred from the supplied image; verify before relying on results.",
    f"R,8,{NEW_THICKNESS:.7f},0,0,0,0,0",
    "ESEL,S,TYPE,,1",
    "ESEL,R,MAT,,1",
    "ESEL,R,REAL,,2",
    f"ESEL,R,CENT,X,{MIN_X:.5f},{MAX_X:.5f}",
    "CM,LB_TIP_THK_PLUS_003,ELEM",
    "EMODIF,ALL,REAL,8",
    "ALLSEL,ALL",
]
modified = lines[:marker] + commands + lines[marker:]
OUTPUT.write_text("\n".join(modified) + "\n")

# Verify the selected element IDs and thickness update operation are explicit.
assert modified.count("EMODIF,ALL,REAL,8") == 1
assert f"R,8,{NEW_THICKNESS:.7f},0,0,0,0,0" in modified
assert f"ESEL,R,CENT,X,{MIN_X:.5f},{MAX_X:.5f}" in modified

print(f"Created: {OUTPUT}")
print(f"Nodes retained: {len(nodes):,}")
print(f"Elements retained: {len(element_lines):,}")
print(f"Tip shell elements selected: {len(target_elements):,}")
print(f"Shell thickness: {ORIGINAL_THICKNESS:.4f} -> {NEW_THICKNESS:.4f} mm")
